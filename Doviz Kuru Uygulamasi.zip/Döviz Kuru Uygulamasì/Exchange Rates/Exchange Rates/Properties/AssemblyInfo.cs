﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

//Bir montaj hakkındaki genel bilgiler, aşağıdaki öznitelikler kümesi aracılığıyla kontrol edilir.
//Montajla ilişkili bilgileri değiştirmek için bu özniteliklerin değerlerini değiştirin.
[assembly: AssemblyTitle("Exchange Rates")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Exchange Rates")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// ComVisible'ı false olarak ayarlamak, bu derlemedeki türleri görünmez yapar COM bileşenleri için.
// Bu derlemede bir türe erişmeniz gerekiyorsa COM, bu türden bir ComVisible niteliğini true olarak ayarlayın.
[assembly: ComVisible(false)]



[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, //temaya özel kaynak sözlüklerinin bulunduğu yer (kaynak sayfada bulunamazsa kullanılır),
                                    
    ResourceDictionaryLocation.SourceAssembly //Genel Kaynaklar Sözlüğü nerede
                                              //(
//                    Kaynağa özel kaynak sözlükleri sayfada, uygulamada veya temada bulunamadığında kullanılır)
)]


// Montaj versiyonu bilgisi aşağıdaki dört değeri içerir:
//
//      Ana sürüm
//      Küçük bir versiyon
//      Yapı numarası
//      Revizyon
//
// Aşağıda gösterildiği gibi "*" sembolünü kullanarak tüm değerleri belirtebilir
// veya varsayılan yapı ve revizyon numaralarını kullanabilirsiniz:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
