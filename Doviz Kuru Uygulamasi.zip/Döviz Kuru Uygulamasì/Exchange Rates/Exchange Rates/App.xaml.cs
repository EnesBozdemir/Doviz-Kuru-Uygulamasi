﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Exchange_Rates
{
    /// <summary>
    /// App.xaml sınıfı için etkileşim mantığı
    /// </summary>
    public partial class App : Application
    {
    }
}
