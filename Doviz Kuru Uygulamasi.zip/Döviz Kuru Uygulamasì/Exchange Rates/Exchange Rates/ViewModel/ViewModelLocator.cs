/*
  In App.xaml:
  <Application.Resources>
      <vm:ViewModelLocator xmlns:vm="clr-namespace:Exchange_Rates"
                           x:Key="Locator" />
  </Application.Resources>
  
  In the View:
  DataContext="{Binding Source={StaticResource Locator}, Path=ViewModelName}"

  T�m bunlar� arac�n deste�iyle yapmak i�in Blend'i de kullanabilirsiniz.
  Git http://www.galasoft.ch/mvvm
*/

using CommonServiceLocator;
using Exchange_Rates.Model.Services;
using GalaSoft.MvvmLight.Ioc;

namespace Exchange_Rates.ViewModel
{
    /// <summary>
    /// S�n�f, t�m statik ModelView referanslar�n� i�erir
    /// uygulamada ve ba�lama i�in giri� noktas� sa�lar
    /// </summary>
    public class ViewModelLocator
    {
        /// <summary>
        ///ViewModelLocator s�n�f�n� ba�lat�r.
        ///</summary>
        public ViewModelLocator()
        {
            ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

            ////if (ViewModelBase.IsInDesignModeStatic)
            ////{
            ////    // Tasar�m zaman� g�r�nt�leme hizmetleri ve modelleri olu�turun
            ////    SimpleIoc.Default.Register<IDataService, DesignDataService>();
            ////}
            ////else
            ////{
            ////    // �al��ma zaman� g�r�nt�leme hizmetleri ve modelleri olu�turun
            SimpleIoc.Default.Register<IDataAccessServices, DataAccessServices>();
            ////}

            SimpleIoc.Default.Register<MainViewModel>();
        }

        public MainViewModel Main
        {
            get
            {
                return ServiceLocator.Current.GetInstance<MainViewModel>();
            }
        }
        
        public static void Cleanup()
        {
            // YAPILACAKLAR ViewModel'leri Temizle
        }
    }
}