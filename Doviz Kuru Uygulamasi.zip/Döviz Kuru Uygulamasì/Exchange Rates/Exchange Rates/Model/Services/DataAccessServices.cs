﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exchange_Rates.Model.Mappings;

namespace Exchange_Rates.Model.Services
{
    /// <summary>
    /// Sunucudan para birimi sorgularını işleme yöntemlerini uygulayan sınıf.
    /// </summary>
    public class DataAccessServices : IDataAccessServices
    {
        Services services = new Services();

        /// <summary>
        /// Ana döviz kuru verilerini alma yönteminin uygulanması
        /// </summary>
        /// <param name="callback">Geri dönen döviz kurlarını veya indirme hatalarını devredin</param>
        public void GetGeneralCurrencies(Action<General, Exception> callback)
        {
            var item = services.GetGeneral((error) => callback(null, error));
            if (item != null)
            {
                callback(item, null);
            }
        }

        /// <summary>
        /// Belirli döviz kurlarına ilişkin verileri alan bir yöntemin uygulanması
        /// </summary>
        /// <param name="callback">Geri dönen döviz kurlarını veya indirme hatalarını devredin</param>
        public void GetSpecificCurrencies(Action<Specific, Exception> callback)
        {
            var item = services.GetSpecific((error) => callback(null, error));
            if (item != null)
            {
                callback(item, null);
            }
        }
    }
}
