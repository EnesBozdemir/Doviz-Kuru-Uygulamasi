﻿using Exchange_Rates.Model.Mappings;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Exchange_Rates.Model.Services
{
    /// <summary>
    /// Sınıf, sunucudan veri almak için yöntemler sağlar.
    /// </summary>
    public class Services
    {
        HttpClient httpClient = new HttpClient();

        /// <summary>
        /// Yöntem ana döviz kurlarını alır.
        /// </summary>
        /// <param name="exceptionCall">Olası veri indirme hatasıyla parametreyi döndür.</param>
        /// <returns>Ana döviz kurlarının eşlenmiş bir nesnesini döndürür.</returns>
        public General GetGeneral(Action<Exception> exceptionCall)
        {
            var table_a_url = ConfigurationManager.AppSettings["table_a_url"];

            try
            {
                var querry = string.Format(@table_a_url);
                var jsonData = httpClient.GetStringAsync(querry).Result;
                var currency = JsonConvert.DeserializeObject<List<General>>(jsonData);
                return currency[0];
            }
            catch (Exception ex)
            {
                exceptionCall(ex);
                return null;
            }

        }

        /// <summary>
        /// Yöntem, ayrıntılı döviz kurlarını alır.
        /// </summary>
        /// <param name="exceptionCall">Olası veri indirme hatasıyla parametreyi döndür.</param>
        /// <returns>Ayrıntılı döviz kurlarının eşlenmiş nesnesini döndürür.</returns>
        public Specific GetSpecific(Action<Exception> exceptionCall)
        {

            var table_c_url = ConfigurationManager.AppSettings["table_c_url"];

            try
            {
                var querry = string.Format(table_c_url);
                var jsonData = httpClient.GetStringAsync(querry).Result;
                var currency = JsonConvert.DeserializeObject<List<Specific>>(jsonData);
                return currency[0];
            }
            catch (Exception ex)
            {
                exceptionCall(ex);
                return null;
            }
        }
    }
}
